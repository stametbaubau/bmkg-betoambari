﻿/**
 * BMKG Betoambari Theme — Main JavaScript
 * Version: 2.0.0 (white theme)
 *
 * Catatan:
 * - Lightbox gambar, dropdown/burger menu, dan jam header sudah ditangani
 *   langsung di header.php & footer.php, jadi TIDAK diduplikasi di sini.
 * - Slider (prakiraan cuaca, pegawai) punya script sendiri di template masing-masing.
 * - File ini hanya berisi fitur global: smooth scroll, back-to-top, load-more.
 */

document.addEventListener('DOMContentLoaded', function () {
	initSmoothScroll();
	initBackToTop();
	initLoadMorePosts();
});

/**
 * Smooth scroll untuk anchor link (#peta-cuaca, dsb).
 * Memperhitungkan tinggi header sticky agar target tidak tertutup.
 */
function initSmoothScroll() {
	document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
		anchor.addEventListener('click', function (e) {
			var targetId = this.getAttribute('href');
			if (targetId.length <= 1) return;

			var target = document.querySelector(targetId);
			if (!target) return;

			e.preventDefault();
			var header = document.querySelector('.bmkg-header');
			var offset = (header ? header.offsetHeight : 0) + 12;
			var top = target.getBoundingClientRect().top + window.pageYOffset - offset;

			window.scrollTo({ top: top, behavior: 'smooth' });
		});
	});
}

/**
 * Tombol "Kembali ke atas".
 * Dibuat via JS, muncul setelah scroll turun. Ikon SVG, warna dari CSS var theme.
 */
function initBackToTop() {
	var btn = document.createElement('button');
	btn.type = 'button';
	btn.className = 'bmkg-back-to-top';
	btn.setAttribute('aria-label', 'Kembali ke atas');
	btn.innerHTML =
		'<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
		'stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
		'<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>';
	document.body.appendChild(btn);

	window.addEventListener('scroll', function () {
		btn.classList.toggle('is-visible', window.pageYOffset > 320);
	}, { passive: true });

	btn.addEventListener('click', function () {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	});
}

/**
 * Load More Posts (AJAX) — opsional.
 * Aktif hanya jika ada tombol .bmkg-load-more DAN object bmkg_ajax tersedia
 * (di-localize dari functions.php). Kalau tidak ada, fungsi berhenti diam-diam.
 */
function initLoadMorePosts() {
	var btn = document.querySelector('.bmkg-load-more');
	if (!btn) return;

	if (typeof bmkg_ajax === 'undefined') {
		btn.style.display = 'none';
		return;
	}

	var page = 1;
	var loading = false;

	btn.addEventListener('click', function () {
		if (loading) return;
		loading = true;

		var original = btn.innerHTML;
		btn.innerHTML = '<span class="bmkg-spinner" aria-hidden="true"></span> Memuat...';
		btn.disabled = true;

		var postType = btn.dataset.postType || 'berita';
		page++;

		fetch(bmkg_ajax.ajax_url, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: new URLSearchParams({
				action: 'load_more_posts',
				page: page,
				post_type: postType,
				nonce: bmkg_ajax.nonce
			})
		})
			.then(function (r) { return r.text(); })
			.then(function (data) {
				var grid = document.querySelector('#bmkg-news-grid') || document.querySelector('.bmkg-card-grid');
				if (data.trim() && grid) {
					grid.insertAdjacentHTML('beforeend', data);
					btn.innerHTML = original;
					btn.disabled = false;
				} else {
					btn.innerHTML = 'Tidak ada lagi';
					btn.disabled = true;
				}
				loading = false;
			})
			.catch(function () {
				btn.innerHTML = 'Gagal memuat';
				btn.disabled = false;
				loading = false;
			});
	});
}
