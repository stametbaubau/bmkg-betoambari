<?php
/**
 * Auto template untuk halaman ber-slug 'profil-bmkg'.
 * WordPress memuat file ini otomatis (hierarki page-{slug}.php),
 * jadi tidak perlu memilih template di editor halaman.
 */
require get_template_directory() . '/profil-bmkg.php';
